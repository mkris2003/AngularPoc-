import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directormain',
  templateUrl: './directormain.component.html',
  styleUrls: ['./directormain.component.css']
})
export class DirectormainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
