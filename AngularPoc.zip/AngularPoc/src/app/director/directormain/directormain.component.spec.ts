import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectormainComponent } from './directormain.component';

describe('DirectormainComponent', () => {
  let component: DirectormainComponent;
  let fixture: ComponentFixture<DirectormainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DirectormainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectormainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
