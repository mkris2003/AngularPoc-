import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DirectorRoutingmodule, DirectorComponents } from './director-routing.module';
import { LoginAuthGuard } from '../login/login-auth.guard';



@NgModule({
  declarations: [ DirectorComponents ],
  imports: [
    CommonModule,
    DirectorRoutingmodule
  ],
  exports:[]
  // providers: [LoginAuthGuard]
})
export class DirectorModule { }
