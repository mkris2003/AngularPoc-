import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directordetails',
  templateUrl: './directordetails.component.html',
  styleUrls: ['./directordetails.component.css']
})
export class DirectordetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
