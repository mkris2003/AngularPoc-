
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DirectormainComponent } from './directormain/directormain.component';
import { DirectordetailsComponent } from './directordetails/directordetails.component';
import { LoginAuthGuard } from '../login/login-auth.guard';

export const DirectorComponents= [ DirectormainComponent, DirectordetailsComponent ];
export const directorRoutes: Routes = [
  { path:"", component:DirectormainComponent , canActivate: [LoginAuthGuard],
  data: { authRoles:['Director']} },
  { path:"directordetails", component:DirectordetailsComponent  , canActivate: [LoginAuthGuard],
  data: { authRoles:['Director']}},
];

@NgModule({
  imports: [RouterModule.forChild( directorRoutes)],
  exports: [RouterModule]
})


export class DirectorRoutingmodule {
}
