import { HttpErrorResponse } from '@angular/common/http';
import { Userdetails } from './../classes/userdetails';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { TokenServiceService } from '../Services/TokenService.service';
import { TokenInfo } from '../classes/TokenInfo';
import { EncryptDecrypt } from '../classes/EncryptDecrypt';
import { ModuleActiveInfo } from '../classes/moduleActiveInfo';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  userdetails=new Userdetails();
  public errorMessage='';
  public tokenInfo = new TokenInfo();
  private encryptDecrypt =new EncryptDecrypt();
   constructor(private router:Router , public tokenService: TokenServiceService ) { }
  public  moduleActiveInfo= new ModuleActiveInfo();
  public submitted=false;
   ngOnInit(): void {
     this.tokenService.clearStorage();
   }
 public loginUser()
 {
  this.submitted= true;
    this.userdetails.password= this.encryptDecrypt.encryptionString(this.userdetails.password);
   // var decrptionstring= this.encryptDecrypt.decryptionString(this.userdetails.password);
   // console.log(decrptionstring);
   this.tokenService.getLoginDetails(this.userdetails)
   .subscribe(data =>
     {
       this.tokenInfo= data;
       localStorage.setItem('token', this.tokenInfo.jwtToken);
       // var roles= this.tokenInfo.roles.map( x => x.roleName).join(',');
      var roles= JSON.stringify(this.tokenInfo.roles)
      // console.log(roles);
       localStorage.setItem('roles', roles);
       var rolesArray = JSON.parse(localStorage.getItem("roles"));
      // console.log(storedNames);
      if(this.tokenInfo.roles)
      {
       let adminIndex= this.tokenInfo.roles.findIndex(obj => obj.roleName === 'Admin');
       if(adminIndex>-1) {
       this.moduleActiveInfo.IsAdminModuleActive= true;
       this.addLocalStorageActiveModule();
       // this.router.navigate(['/admin']);
       //  return;
       }

       let directorIndex= this.tokenInfo.roles.findIndex(obj => obj.roleName === 'Director');
       if(directorIndex>-1) {
       this.moduleActiveInfo.IsDirectorModuleActive= true;
       this.addLocalStorageActiveModule();
       // this.router.navigate(['/director']);
        // return;
       }
       this.router.navigate(['/sidenav'], { replaceUrl: true });
      }
      else{
       this.router.navigate(['/login']); return;
      }
     }
  // ,  error => this.errorMessage = error
  );
 }

 addLocalStorageActiveModule()
 {
   var modulesActive= JSON.stringify(this.moduleActiveInfo)
   // console.log(roles);
    localStorage.setItem('moduleActiveInfo', modulesActive);
 }

}
