export class Userdetails {
    userName:string;
    password:string;
}
