export class Roles {
    roleID : number;
    roleName : string;
}
