import { GlobalErrorHandler } from './global-error-handler';

describe('GlobalErrorHandler', () => {
  it('should create an instance', () => {
    expect(new GlobalErrorHandler()).toBeTruthy();
  });
});
