import { Roles } from './Roles';
export class TokenInfo {
    jwtToken:string;
    roles: Roles[];
}
