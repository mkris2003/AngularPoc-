
import * as CryptoJS from 'crypto-js';
export class EncryptDecrypt {
    private key: string=CryptoJS.enc.Utf8.parse('rMDTU3oS2kiRPOH7vjxNcg==');
    private iv:string=CryptoJS.enc.Utf8.parse('rMDTU3oS2kiRPOH7');

    public encryptionString( plainText:string ):string {

         var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(plainText), this.key,
        {
            keySize: 128 / 8,
            iv: this.iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }).toString();
        console.log(encrypted);
        return encrypted;
      }

      public  decryptionString(encryptionString:string ): string
      {
        var decrypted = CryptoJS.AES.decrypt(encryptionString, this.key, {
            keySize: 128 / 8,
            iv: this.iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        return decrypted.toString(CryptoJS.enc.Utf8);
      }

}
