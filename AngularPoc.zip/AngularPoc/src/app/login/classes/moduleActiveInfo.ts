export class ModuleActiveInfo {
    IsAdminModuleActive:boolean=false;
    IsDirectorModuleActive:boolean=false;
    IsManagerModuleActive:boolean=false;
}
