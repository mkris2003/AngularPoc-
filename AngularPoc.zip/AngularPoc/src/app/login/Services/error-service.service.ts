import { throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ErrorServiceService {

  constructor() { }

  handleError(error ) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
        // client-side error
        errorMessage = `Error: ${error.error.message}`;
    } else {
        // server-side error
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }


  getClientMessage(error: Error ): string {
    if (!navigator.onLine) {
        return 'No Internet Connection';
    }
    return error.message ? error.message : error.toString();
}

getClientStack(error: Error ): string {
    return error.stack;
}

getServerMessage(error: HttpErrorResponse ): string {
    return error.message;
}

getServerStack(error: HttpErrorResponse ): string {
    // handle stack trace
    return 'stack';
}
}
