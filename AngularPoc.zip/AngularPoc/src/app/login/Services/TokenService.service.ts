import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from  '@angular/common/http';
import { Observable, throwError, observable } from 'rxjs';
import 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { TokenInfo } from '../classes/TokenInfo';
import { Userdetails } from '../classes/userdetails';
import { Roles } from '../classes/Roles';
import { ErrorServiceService } from './error-service.service';
@Injectable({
  providedIn: 'root'
})
export class TokenServiceService {
  private _url:string="https://localhost:5001/UserDetails/LoginUserDetails";
constructor(private http:HttpClient , private _router: Router
  , private errorService: ErrorServiceService ) { }

public getLoginDetails(userdetails: Userdetails ):Observable< TokenInfo>
{
  let httpParams = new HttpParams();
  httpParams= httpParams.append('userName', userdetails.userName);
  httpParams= httpParams.append('password', userdetails.password);

  // var withOutParamUrl= `${this._url}/${userdetails.userName}/${userdetails.password}`;
  return this.http.get< TokenInfo>(this._url, { params: httpParams} );// .pipe(
  //   catchError(this.errorService.handleError)
  // );
}

loggedIn() {
  return !!localStorage.getItem('token'); // it will return  true or false
}

HasRoles() {
  return !!localStorage.getItem('roles'); // it will return  true or false
}
getToken() {
  return localStorage.getItem('token');
}

getRoles() {
  return JSON.parse(localStorage.getItem("roles"));
}
getModuleActiveInfo(){
  return JSON.parse(localStorage.getItem("moduleActiveInfo"));
}

clearStorage()
{
  localStorage.removeItem('token');
  localStorage.removeItem('roles');
  localStorage.removeItem('moduleActiveInfo');
}

logoutUser()
{
  this.clearStorage();
  this._router.navigate(['/']);
}
roleMatch(allowedRoles :string[] ): boolean{
var isMatch= false;
var roles: Roles[]= JSON.parse(localStorage.getItem("roles"));
if(roles && allowedRoles){
  roles.forEach(item => {
    let index = allowedRoles.findIndex(obj => obj === item.roleName);
   // console.log(index);
    if(index>-1){
      isMatch= true;
      return false;
     }
  });
  return isMatch;

}
}


}
