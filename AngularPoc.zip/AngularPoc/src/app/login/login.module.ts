import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule} from '@angular/forms';
import { HttpClientModule } from  '@angular/common/http';
import { LoginRoutingModule } from './login-routing.module';
import { SideNaveMainModule } from '../side-nave-main/side-nave-main.module';
import { LoginPageComponent } from './login-page/login-page.component';

const SubModules= [ SideNaveMainModule ];

@NgModule({
  declarations: [ LoginPageComponent ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    LoginRoutingModule,
    // SubModules
  ],
  exports:[]
})
export class LoginModule { }
