import { LoginRouting.Module } from './login-routing.module';

describe('LoginRouting.Module', () => {
  it('should create an instance', () => {
    expect(new LoginRouting.Module()).toBeTruthy();
  });
});
