import {  Injectable, Injector } from '@angular/core';
import { HttpInterceptor } from '@angular/common/http'
import { TokenServiceService } from './Services/TokenService.service';
@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector ){}
  intercept(req , next ) {
    let tokenService = this.injector.get(TokenServiceService)
    let tokenizedReq = req.clone(
      {
        headers: req.headers.set('Authorization', 'bearer ' + tokenService.getToken())
      }
    )
    return next.handle(tokenizedReq)
  }
}
