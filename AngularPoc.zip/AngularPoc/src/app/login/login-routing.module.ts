
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';




export const routes: Routes = [

  { path:"", component:LoginPageComponent  }
  // {path: 'sidenavmain', loadChildren: () => import('../side-nave-main/side-nave-main.module').then(m => m.SideNaveMainModule)}
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class LoginRoutingModule {
}
