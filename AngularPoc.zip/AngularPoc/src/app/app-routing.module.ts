// import { LoginPageComponent } from './../../../BackUp/AngularPOC/src/app/login/login-page/login-page.component';
// import { PagenotfoundComponent } from './login/pagenotfound/pagenotfound.component';
// import { DirectormainComponent } from './director/directormain/directormain.component';
// import { AdminMainComponent } from './admin/admin-main/admin-main.component';
// import { LoginPageComponent } from './login/login-page/login-page.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SidenavComponent } from './side-nave-main/sidenav/sidenav.component';
import { LoginAuthGuard } from './login/login-auth.guard';
// import { AppComponent } from './app.component';
// import { LoginAuthGuard } from './login/login-auth.guard';
// import { AuthloginComponent } from './authlogin/authlogin.component';

// const routes: Routes = [
//   { path:"", redirectTo:'/login', pathMatch:'full'},
//   { path:"login", component:LoginPageComponent },
//   { path:"admin", component:AdminMainComponent, canActivate: [LoginAuthGuard], data: { authRoles:['Admin']}},
//   { path:"director", component:DirectormainComponent , canActivate: [LoginAuthGuard], data: { authRoles:['Director']} },
//   { path:"**", component:PagenotfoundComponent}
// ];

// export const routes: Routes = [
//   { path:"", redirectTo:'/auth', pathMatch:'full'},
//   { path:"auth", component:AuthloginComponent   },
//   // {path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)},
//   {path: 'admin' , canActivate: [LoginAuthGuard],
//   data: { authRoles:['Admin']}, loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)},
//   {path: 'director' , canActivate: [LoginAuthGuard],
//    data: { authRoles:['Director']} , loadChildren: () => import('./director/director.module').then(m => m.DirectorModule)},
// ];
// export const RoutingComponents= [LoginPageComponent, AdminMainComponent, DirectormainComponent ];
export const routes: Routes = [

    {path: '', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)},
    {path: 'sidenav', component:SidenavComponent,
    children: [
        {path: 'admin' , canActivate: [LoginAuthGuard],
            data: { authRoles:['Admin']}, loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)},
        {path: 'director' , canActivate: [LoginAuthGuard],
            data: { authRoles:['Director']} , loadChildren: () => import('./director/director.module').then(m => m.DirectorModule)}
    ]
     }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
