import { Observable } from 'rxjs';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Country } from '../classes/country';
import { State } from '../classes/state';
import { City } from '../classes/city';
import { Gender } from '../classes/gender';
import { AdminInfo } from '../classes/admininfo';
import { validateHorizontalPosition } from '../../../../node_modules/@angular/cdk/overlay';
import { DropdownValidation } from '../validation/dropdownValidation';

@Component({
  selector: 'app-admin-entry',
  templateUrl: './admin-entry.component.html',
  styleUrls: ['./admin-entry.component.css']
})
export class AdminEntryComponent implements OnInit {
  adminEntryForm :FormGroup;
  public countryList :Country[];
  public stateList :State[];
  public cityList :City[];
  public adminInfo= new AdminInfo('','',null,new Date(),-1,-1,-1);
  public submitted=false;
  constructor(private fb:FormBuilder ) { }

  ngOnInit(): void {
   this.reactValidate();
    this.getCountrys().subscribe((countryData: Country[] ) => {
      this.countryList = countryData;
  });
  }

  reactValidate()
  {
    this.adminEntryForm= this.fb.group({
      adminFirstName : ['', [ Validators.required]],
      adminLastName: ['', [ Validators.required]],
      joinDate: ['', [ Validators.required]],
      gender: [null , [ Validators.required]],
      country: [-1 , [ Validators.required, DropdownValidation.selectDropdown]],
      state: [-1 , [ Validators.required, DropdownValidation.selectDropdown]],
      city:[-1 , [ Validators.required, DropdownValidation.selectDropdown]]
    });
  }
  get adminFirstName()
  {
    return this.adminEntryForm.get('adminFirstName');
  }
  get adminLastName()
  {
    return this.adminEntryForm.get('adminLastName');
  }
  get joinDate()
  {
    return this.adminEntryForm.get('joinDate');
  }
  get gender()
  {
    return this.adminEntryForm.get('gender');
  }
  get country()
  {
    return this.adminEntryForm.get('country');
  }
  get state()
  {
    return this.adminEntryForm.get('state');
  }
  get city()
  {
    return this.adminEntryForm.get('city');
  }
  onCountrySelect(country )
  {
    // console.log(country);
    this.getStates().subscribe((stateData: State[] ) => {
      this.stateList = stateData.filter((item ) => item.countryId == country.value);
      if(this.stateList)
        this.stateList.splice(0, 0, { stateId:-1, stateName:'Select State', countryId:country.value});
  });

  }
  onStateSelect(state )
  {
    this.getCitys().subscribe((cityData: City[] ) => {
      this.cityList = cityData.filter((item ) => item.countryId == this.adminInfo.countryId && item.stateId== state.value  );
      if(this.cityList)
        this.cityList.splice(0, 0,  {cityId:-1, cityName:'Select City', stateId:state.value, countryId:this.adminInfo.countryId});
  });

  }

  public getCountrys(): any {
    const countrysObservable = new Observable(observer => {
               observer.next(this.countrys);
    });
    return countrysObservable;
}
public getStates(): any {
  const statesObservable = new Observable(observer => {
             observer.next(this.states);
  });
  return statesObservable;
}

public getCitys(): any {
  const citysObservable = new Observable(observer => {
             observer.next(this.citys);
  });
  return citysObservable;
}

onSubmit()
{
  this.submitted= true;
console.log(this.adminInfo);
this.submitted= false;
}
public countrys :Country[]=[
  { countryId:-1 , countryName:'Select Country'},
  { countryId:1 , countryName:'India'},
  { countryId:2 , countryName:'USA'},
];

public states :State[]=[
  {stateId:-1,stateName:'Select State',countryId:-1},
  {stateId:1,stateName:'AP',countryId:1},
  {stateId:2,stateName:'TN',countryId:1},
  {stateId:3,stateName:'KT',countryId:1},
  {stateId:3,stateName:'MH',countryId:1},
  {stateId:1,stateName:'TX',countryId:2},
  {stateId:2,stateName:'AZ',countryId:2}
];

public citys :City[]=[
 {cityId:-1,cityName:'Select City',stateId:-1,countryId:-1},
 {cityId:1,cityName:'kondikandukur',stateId:1,countryId:1},
 {cityId:2,cityName:'kandukur',stateId:1,countryId:1},
 {cityId:3,cityName:'chennai',stateId:2,countryId:1},
 {cityId:4,cityName:'houston',stateId:1,countryId:2},
 {cityId:5,cityName:'scotsdale',stateId:2,countryId:2},
];
public genderList :Gender[]=[
  {genderId:-1,genderName:'None' },
  {genderId:1,genderName:'Male' },
  {genderId:2,genderName:'Female' }
]
}
