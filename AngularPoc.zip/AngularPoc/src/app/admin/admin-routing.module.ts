import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminMainComponent } from './admin-main/admin-main.component';
import { AdminDetailsComponent } from './admin-details/admin-details.component';
import { AdminEntryComponent } from './admin-entry/admin-entry.component';
import { LoginAuthGuard } from '../login/login-auth.guard';

export const AdminComponents= [ AdminMainComponent, AdminDetailsComponent,  AdminEntryComponent]

export const adminRoutes: Routes = [
  { path:"", component:AdminMainComponent , canActivate: [LoginAuthGuard],
  data: { authRoles:['Admin']} },
  { path:"admindetails", component:AdminDetailsComponent , canActivate: [LoginAuthGuard],
  data: { authRoles:['Admin']}},
  { path:"adminentry", component:AdminEntryComponent , canActivate: [LoginAuthGuard],
  data: { authRoles:['Admin']} },
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
