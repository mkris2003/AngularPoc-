export class Gender {
    genderId:number;
    genderName:string;
}
