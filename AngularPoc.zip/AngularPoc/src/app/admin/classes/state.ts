export class State {
    stateId:number;
    stateName:string;
    countryId:number;
}

