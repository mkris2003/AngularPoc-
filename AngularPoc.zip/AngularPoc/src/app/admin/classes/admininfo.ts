

export class AdminInfo {
    constructor(public  adminFirstName:string ,
     public adminLastName:string ,
     public genderId:number ,
     public joinDate:Date ,
     public  countryId :number ,
     public  stateId:number ,
     public  cityId:number )
    {}
  }
