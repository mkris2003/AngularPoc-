export class City {
    cityId:number;
    cityName:string;
    stateId:number;
    countryId:number;
}
