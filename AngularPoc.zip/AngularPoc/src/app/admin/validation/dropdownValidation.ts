
import { AbstractControl, ValidationErrors } from '@angular/forms';

export class DropdownValidation {
    static selectDropdown(control: AbstractControl ) : ValidationErrors | null {
        if((control.value as number)==-1){
            return {selectDropdown: true}
        }
        return null ;
    }
}
