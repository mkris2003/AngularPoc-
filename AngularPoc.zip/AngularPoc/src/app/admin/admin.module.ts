import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminRoutingModule } from './admin-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginAuthGuard } from '../login/login-auth.guard';
import { MaterialModule } from '../material/material.module';
import { LayoutModule } from '@angular/cdk/layout';
import { AdminMainComponent } from './admin-main/admin-main.component';
import { AdminEntryComponent } from './admin-entry/admin-entry.component';
import { AdminDetailsComponent } from './admin-details/admin-details.component';




@NgModule({
  declarations: [AdminMainComponent, AdminEntryComponent,AdminDetailsComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    MaterialModule,
    LayoutModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[]
  // providers: [LoginAuthGuard]
})
export class AdminModule { }
