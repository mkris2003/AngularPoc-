
import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { TokenServiceService } from '../../login/Services/TokenService.service';


@Component({
  selector: 'app-navmenu',
  templateUrl: './navmenu.component.html',
  styleUrls: ['./navmenu.component.css']
})
export class NavmenuComponent implements OnInit {

  public moduleActiveInfo = this.tokenService.getModuleActiveInfo();
  title = 'Angular Poc';
  // let moduleActiveInfo= JSON.parse(localStorage.getItem("moduleActiveInfo"));

isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

constructor(private breakpointObserver: BreakpointObserver ,
  public tokenService: TokenServiceService  ) {}

  ngOnInit() {
  }

  onLogout()
  {

  }
}
