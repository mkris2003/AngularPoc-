import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginAuthGuard } from '../login/login-auth.guard';
import { SidenavComponent } from './sidenav/sidenav.component';


export const routes: Routes = [];
//   { path:"", component:SidenavComponent  },
//   {path: 'admin' , canActivate: [LoginAuthGuard],
//   data: { authRoles:['Admin']}, loadChildren: () => import('../admin/admin.module').then(m => m.AdminModule)},
//   {path: 'director' , canActivate: [LoginAuthGuard],
//    data: { authRoles:['Director']} , loadChildren: () => import('../director/director.module').then(m => m.DirectorModule)},
// ];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SideNaveMainRoutingModule { }
