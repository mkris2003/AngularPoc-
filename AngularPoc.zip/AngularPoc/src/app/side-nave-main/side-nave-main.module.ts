import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SideNaveMainRoutingModule } from './side-nave-main-routing.module';
import { AdminModule } from '../admin/admin.module';
import { DirectorModule } from '../director/director.module';
import { NavmenuComponent } from './navmenu/navmenu.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { MaterialModule } from '../material/material.module';

export const SubModules= [  AdminModule, DirectorModule ];

@NgModule({
  declarations: [NavmenuComponent,SidenavComponent],
  imports: [
    CommonModule,
    SideNaveMainRoutingModule,
    // SubModules,
    MaterialModule
  ]
})
export class SideNaveMainModule { }
