import { DirectorModule } from './director/director.module';
import { AdminModule } from './admin/admin.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import{ FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from  '@angular/common/http';
import { LoginAuthGuard } from './login/login-auth.guard';
import { TokenInterceptorService } from './login/token-interceptor.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { SideNaveMainModule } from './side-nave-main/side-nave-main.module';
import { GlobalErrorHandler } from './login/classes/global-error-handler';
import { ServerErrorInterceptor } from './login/server-error.interceptor';
// import { AuthloginComponent } from './authlogin/authlogin.component';
// import { NavMenuComponent } from './nav-menu/nav-menu.component';
// import { LayoutModule } from '@angular/cdk/layout';
// import { MatToolbarModule } from '@angular/material/toolbar';
// import { MatButtonModule } from '@angular/material/button';
// import { MatSidenavModule } from '@angular/material/sidenav';
// import { MatIconModule } from '@angular/material/icon';
// import { MatListModule } from '@angular/material/list';

const SubModules= [ LoginModule, SideNaveMainModule, AdminModule, DirectorModule ];
// const SubModules= [ LoginModule];
@NgModule({
  declarations: [
    AppComponent
    // AuthloginComponent,
    // NavMenuComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SubModules,
    MaterialModule,
    ReactiveFormsModule
    // LayoutModule,
    // MatToolbarModule,
    // MatButtonModule,
    // MatSidenavModule,
    // MatIconModule,
    // MatListModule
  ],
  exports:[
  ],
  providers: [LoginAuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    },
    {provide: ErrorHandler, useClass: GlobalErrorHandler  },
    { provide: HTTP_INTERCEPTORS, useClass: ServerErrorInterceptor, multi: true }
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
