import { Routes, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularPOC';

//   static  appRoutes: Routes= [
//     { path:"adminMain", component:AdminMainComponent }
//  ];

}
