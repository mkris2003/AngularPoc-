﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using DataModels.Interfaces;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace WebApiJwtToken.Classes
{
    public class TokenRepository : ITokenRepository
    {
        private readonly AppSettings _appSettings;
        public TokenRepository(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }
        public string GetNewToken()
        {
           // return _appSettings.Secret;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, _appSettings.Secret)
                }),
                Expires = DateTime.UtcNow.AddHours(_appSettings.ExpireHours),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor); 
            var newToken= tokenHandler.WriteToken(token);
            return newToken;
        }
        public bool ValidateCurrentToken(string token)
        {           
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_appSettings.Secret)); 
            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    IssuerSigningKey = mySecurityKey
                }, out SecurityToken validatedToken);
                
            }
            catch(Exception exception)
            {
                var error = exception.Message;
                return false;
            }
            return true;
        }
    }
}
