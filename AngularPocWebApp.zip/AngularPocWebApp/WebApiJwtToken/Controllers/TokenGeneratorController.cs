﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataModels.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApiJwtToken.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class TokenGeneratorController : ControllerBase
    {
        private readonly ITokenRepository _tokenRepository;
        public TokenGeneratorController(ITokenRepository tokenRepository)
        {
            _tokenRepository = tokenRepository;
        }
        //https://localhost:5001/TokenGenerator/GetToken
        //http://localhost:5000/TokenGenerator/GetToken
        //http://localhost/JwtTokenWebapiCore31/TokenGenerator/GetToken
        [HttpGet]
        public async Task<IActionResult> GetToken()
        {
            try
            {
                var token = await Task.Run(() => _tokenRepository.GetNewToken());
                return Ok(token);
            }
            catch (Exception exception)
            {
                return new NotFoundObjectResult(exception);
            }
        }
        //https://localhost:5001/TokenGenerator/ValidateToken
        [HttpPost]
        public async Task<IActionResult> ValidateToken([FromBody] string token)
        {
            try
            {
                var isValid = await Task.Run(() => _tokenRepository.ValidateCurrentToken(token));
                return Ok(isValid);
            }
            catch (Exception exception)
            {
                return new NotFoundObjectResult(exception);
            }
        }
    }
}