﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModels.Classes
{
   public class TokenInfo
    {
        public string JwtToken { get; set; }
        public List<Roles> Roles { get; set; }
    }
}
