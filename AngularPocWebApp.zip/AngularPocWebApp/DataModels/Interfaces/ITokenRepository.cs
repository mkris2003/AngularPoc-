﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModels.Interfaces
{
   public interface ITokenRepository
    {
        string GetNewToken();
        bool ValidateCurrentToken(string token);
    }
}
