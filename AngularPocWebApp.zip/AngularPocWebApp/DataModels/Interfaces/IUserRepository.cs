﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DataModels.Classes;

namespace DataModels.Interfaces
{
   public interface IUserRepository
    {
        Task<IEnumerable<UserDetails>> GetUserDetails(string userName);
    }
}
