﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AngularPocWebApp.Enums;
using static AngularPocWebApp.Enums.RegisteredHttpClients;

namespace AngularPocWebApp.HttpClients
{
    public class HttpClientSettings
    {
        public Dictionary<string, string> ServiceClients { get; set; }
    }
}
