﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using AngularPocWebApp.HttpClients;
using Microsoft.Extensions.Options;
using static AngularPocWebApp.Enums.RegisteredHttpClients;

namespace AngularPocWebApp.HttpClients
{
    public class JwtTokenServiceClient
    {
        private readonly IOptions<HttpClientSettings> _httpClientSettings;
        private readonly HttpClient _client;
        public JwtTokenServiceClient(IOptions<HttpClientSettings> httpClientSettings, HttpClient client)
        {
            _httpClientSettings = httpClientSettings;
            var clients = _httpClientSettings.Value.ServiceClients;
            clients.TryGetValue(nameof(RegisteredClients.WebApiJwtTokenServiceClient), out string url);
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders
                  .Accept
                  .Add(new MediaTypeWithQualityHeaderValue("application/json"));//ACCEPT header

            _client = client;
        }

        public async Task<string> GetNewJwtToken()
        {
            string token = string.Empty;
            try
            {
                var response = await _client.GetAsync("JwtTokenWebapiCore31/TokenGenerator/GetToken");

                if (response.IsSuccessStatusCode)
                {
                    using var responseStream = await response.Content.ReadAsStreamAsync();
                    token = await JsonSerializer.DeserializeAsync
                        <string>(responseStream);
                }
            }
            catch (Exception exception)
            {
                var _exception = exception;

            }
            return token;
        }
        public async Task<bool> ValidateToken(string token)
        {
            bool isValidToken = false;
            try
            {

                var stringContent = new StringContent(JsonSerializer.Serialize(token), Encoding.UTF8, "application/json");
                var response = await _client.PostAsync("JwtTokenWebapiCore31/TokenGenerator/ValidateToken", stringContent);

                if (response.IsSuccessStatusCode)
                {
                    using var responseStream = await response.Content.ReadAsStreamAsync();
                    isValidToken = await JsonSerializer.DeserializeAsync
                        <bool>(responseStream);
                }
            }
            catch (Exception exception)
            {
                var _exception = exception;

            }
            return isValidToken;
        }
    }
}
