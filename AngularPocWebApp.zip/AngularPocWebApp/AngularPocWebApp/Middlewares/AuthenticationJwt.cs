﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace AngularPocWebApp.Middlewares
{
    public class AuthenticationJwt
    {
        private readonly RequestDelegate _next;

        public AuthenticationJwt(RequestDelegate next)
        {
            _next = next;
        }

        // IMyScopedService is injected into Invoke
        public async Task Invoke(HttpContext httpContext)
        {
           var token =Convert.ToString(  httpContext.Request.Headers["Authorization"]);

            await _next(httpContext);
        }
    }
}
