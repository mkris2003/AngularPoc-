﻿using System;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;


namespace AngularPocWebApp.Common
{
    public static class Cipher
    {
        public static string key = "rMDTU3oS2kiRPOH7vjxNcg==", iv = "rMDTU3oS2kiRPOH7";

        //public static byte[] EncryptStringToBytes_Aes(string plainText, byte[] key, byte[] iv)
        //{
        //    if (plainText == null || plainText.Length <= 0)
        //        throw new ArgumentNullException(nameof(plainText));
        //    if (key == null || key.Length <= 0)
        //        throw new ArgumentNullException(nameof(key));
        //    if (iv == null || iv.Length <= 0)
        //        throw new ArgumentNullException(nameof(iv));
        //    byte[] encrypted;

        //    using (var aesAlg = Aes.Create())
        //    {
        //        aesAlg.Key = key;
        //        aesAlg.IV = iv;

        //        var encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
        //        using (var msEncrypt = new MemoryStream())
        //        {
        //            using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
        //            {
        //                using (var swEncrypt = new StreamWriter(csEncrypt))
        //                {
        //                    swEncrypt.Write(plainText);
        //                }
        //                encrypted = msEncrypt.ToArray();
        //            }
        //        }
        //    }

        //    return encrypted;
        //}

        public static string EncryptAES( this string plainText)//byte[] Key, byte[] IV
        {
            byte[] encrypted;

             

          
            // Create a new AesManaged.    
            using (AesManaged aes = new AesManaged())
            {
                aes.Key = Encoding.UTF8.GetBytes(key); //UTF8.GetBytes(keyValue); 
                aes.IV = Encoding.UTF8.GetBytes(iv);
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.FeedbackSize = 128;

                 // Create encryptor    
                 ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV); //Key, IV
                // Create MemoryStream    
                using (MemoryStream ms = new MemoryStream())
                {
                    // Create crypto stream using the CryptoStream class. This class is the key to encryption    
                    // and encrypts and decrypts data from any given stream. In this case, we will pass a memory stream    
                    // to encrypt 
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        // Create StreamWriter and write data to a stream    
                        using (StreamWriter sw = new StreamWriter(cs))
                            sw.Write(plainText);
                        encrypted = ms.ToArray();
                    }
                }
            }

            // Return encrypted data    

            string utfstring= Convert.ToBase64String(encrypted);
            // return  ByteArrayToHexString(encrypted);
            // return encrypted;
            return utfstring;
        }


    public static string DecryptAES(this string Text)
        {
            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.IV = Encoding.UTF8.GetBytes(iv);
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            byte[] src = System.Convert.FromBase64String(Text);
            using (ICryptoTransform decrypt = aes.CreateDecryptor())
            {
                byte[] dest = decrypt.TransformFinalBlock(src, 0, src.Length);
                return Encoding.UTF8.GetString(dest);
            }
        }

        //public static string DecryptStringFromBytes_Aes(byte[] cipherText, byte[] key, byte[] iv)
        //{
        //    if (cipherText == null || cipherText.Length <= 0)
        //        throw new ArgumentNullException(nameof(cipherText));
        //    if (key == null || key.Length <= 0)
        //        throw new ArgumentNullException(nameof(key));
        //    if (iv == null || iv.Length <= 0)
        //        throw new ArgumentNullException(nameof(iv));

        //    string plaintext;
        //    using (var aesAlg = Aes.Create())
        //    {
        //        aesAlg.Key = key;
        //        aesAlg.IV = iv;

        //        var decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
        //        using (var msDecrypt = new MemoryStream(cipherText))
        //        {
        //            using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
        //            {
        //                using (var srDecrypt = new StreamReader(csDecrypt))
        //                {
        //                    plaintext = srDecrypt.ReadToEnd();
        //                }
        //            }
        //        }

        //    }

        //    return plaintext;
        //}

        //private  static string password = "OM@123";
        ///// <summary>
        ///// Encrypt a string.
        ///// </summary>
        ///// <param name="plainText">String to be encrypted</param>
        ///// <param name="password">Password</param>
        //public static string Encrypt(this string plainText)
        //{
        //    if (plainText == null)
        //    {
        //        return null;
        //    }

        //    if (password == null)
        //    {
        //        password = String.Empty;
        //    }

        //    // Get the bytes of the string
        //    var bytesToBeEncrypted = Encoding.UTF8.GetBytes(plainText);
        //    var passwordBytes = Encoding.UTF8.GetBytes(password);

        //    // Hash the password with SHA256
        //    passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

        //    var bytesEncrypted = Cipher.Encrypt(bytesToBeEncrypted, passwordBytes);

        //    return Convert.ToBase64String(bytesEncrypted);
        //}

        ///// <summary>
        ///// Decrypt a string.
        ///// </summary>
        ///// <param name="encryptedText">String to be decrypted</param>
        ///// <param name="password">Password used during encryption</param>
        ///// <exception cref="FormatException"></exception>
        //public static string Decrypt(this string encryptedText)
        //{
        //    if (encryptedText == null)
        //    {
        //        return null;
        //    }

        //    if (password == null)
        //    {
        //        password = String.Empty;
        //    }

        //    // Get the bytes of the string
        //    var bytesToBeDecrypted = Convert.FromBase64String(encryptedText);
        //    var passwordBytes = Encoding.UTF8.GetBytes(password);

        //    passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

        //    var bytesDecrypted = Cipher.Decrypt(bytesToBeDecrypted, passwordBytes);

        //    return Encoding.UTF8.GetString(bytesDecrypted);
        //}

        //private static byte[] Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
        //{
        //    byte[] encryptedBytes = null;

        //    // Set your salt here, change it to meet your flavor:
        //    // The salt bytes must be at least 8 bytes.
        //    var saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

        //    using (MemoryStream ms = new MemoryStream())
        //    {
        //        using (RijndaelManaged AES = new RijndaelManaged())
        //        {
        //            var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);

        //            AES.KeySize = 256;
        //            AES.BlockSize = 128;
        //            AES.Key = key.GetBytes(AES.KeySize / 8);
        //            AES.IV = key.GetBytes(AES.BlockSize / 8);

        //            AES.Mode = CipherMode.CBC;

        //            using (var cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
        //            {
        //                cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
        //                cs.Close();
        //            }

        //            encryptedBytes = ms.ToArray();
        //        }
        //    }

        //    return encryptedBytes;
        //}

        //private static byte[] Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        //{
        //    byte[] decryptedBytes = null;

        //    // Set your salt here, change it to meet your flavor:
        //    // The salt bytes must be at least 8 bytes.
        //    var saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

        //    using (MemoryStream ms = new MemoryStream())
        //    {
        //        using (RijndaelManaged AES = new RijndaelManaged())
        //        {
        //            var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);

        //            AES.KeySize = 256;
        //            AES.BlockSize = 128;
        //            AES.Key = key.GetBytes(AES.KeySize / 8);
        //            AES.IV = key.GetBytes(AES.BlockSize / 8);
        //            AES.Mode = CipherMode.CBC;

        //            using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
        //            {
        //                cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
        //                cs.Close();
        //            }

        //            decryptedBytes = ms.ToArray();
        //        }
        //    }

        //    return decryptedBytes;
        //}
    }
}
