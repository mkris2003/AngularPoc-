﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using AngularPocWebApp.HttpClients;
using AngularPocWebApp.HttpClients;
using DataModels.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using static AngularPocWebApp.Common.Cipher;
using static AngularPocWebApp.Enums.RegisteredHttpClients;

namespace AngularPocWebApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IRolesRespository _rolesRespository;
        private readonly IUserRepository _userRepository;
        private readonly JwtTokenServiceClient _jwtTokenServiceClient;
        public WeatherForecastController(ILogger<WeatherForecastController> logger, IRolesRespository rolesRespository, IUserRepository userRepository, JwtTokenServiceClient jwtTokenServiceClient)
        {
            _logger = logger;
            _rolesRespository = rolesRespository;
            _userRepository = userRepository;
            _jwtTokenServiceClient = jwtTokenServiceClient;
            Guid g = Guid.NewGuid();
            string GuidString = Convert.ToBase64String(g.ToByteArray());

            var angle= Math.Abs(5 * ((6 * 1) - (1.1 * 1)));
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {

         var result=   _jwtTokenServiceClient.GetNewJwtToken();
        var isvalid=    _jwtTokenServiceClient.ValidateToken(result.Result).Result;
            var encryptString = "OMNamoVenkatesaya".EncryptAES();
            var decryptString = encryptString.DecryptAES();
          var userList=  _userRepository.GetUserDetails("test");
         var roles=    _rolesRespository.GetRoles();
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
