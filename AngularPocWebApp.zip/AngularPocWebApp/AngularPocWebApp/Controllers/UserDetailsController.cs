﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AngularPocWebApp.Common;
using AngularPocWebApp.HttpClients;
using AngularPocWebApp.HttpClients;
using DataModels.Classes;
using DataModels.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static AngularPocWebApp.Common.Cipher;
using static AngularPocWebApp.Extensions.StringExtensions;


namespace AngularPocWebApp.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class UserDetailsController : ControllerBase
    {
        private readonly IRolesRespository _rolesRespository;
        private readonly IUserRepository _userRepository;
        private readonly JwtTokenServiceClient _jwtTokenServiceClient;
        public UserDetailsController(IRolesRespository rolesRespository, IUserRepository userRepository, JwtTokenServiceClient jwtTokenServiceClient)
        {
            _rolesRespository = rolesRespository;
            _userRepository = userRepository;
            _jwtTokenServiceClient = jwtTokenServiceClient;
        }
        //https://localhost:5001/UserDetails/GetRoles
        [HttpGet]
        public async Task<IActionResult> GetRoles()
        {
            try
            {
                var roles = await _rolesRespository.GetRoles();
                return Ok(roles);
            }
            catch(Exception exception)
            {
                return new NotFoundObjectResult(exception);
            }

        }
        //  https://localhost:5001/UserDetails/LoginUserDetails/test/test
        //https://localhost:5001/UserDetails/LoginUserDetails?userName='tes'&password='test'
        [HttpGet]
        public async Task<IActionResult> LoginUserDetails([FromQuery] string userName, [FromQuery] string password)
        {
            try
            {

                password = password.DecryptAES();
                var userDetails = await _userRepository.GetUserDetails(userName);
                if(userDetails.Count()>0)
                {
                    var token = await _jwtTokenServiceClient.GetNewJwtToken();
                    if (token.IsStringValid())
                    {
                        var tokenInfo = new TokenInfo
                        {
                            JwtToken = token,
                            Roles = userDetails.ToList().ElementAtOrDefault(0).Roles
                        };
                        return Ok(tokenInfo);
                    }
                }
               
            }
            catch (Exception exception)
            {
                return new NotFoundObjectResult(exception);
            }
            return null;
        }
    }
}