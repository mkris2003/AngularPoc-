﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularPocWebApp.Enums
{
    public class RegisteredHttpClients
    {
      
        public enum RegisteredClients
        {
            WebApiJwtTokenServiceClient,
            EmployeeServcieClient
        }
    }
    
}
