using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using AngularPocWebApp.HttpClients;
using AngularPocWebApp.Extensions;
using DataAccessLayer;
using DataAccessLayer.RepositoryClasses;
using DataModels.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using static AngularPocWebApp.Constants.DataAcessLayerConstants;
using AngularPocWebApp.Middlewares;

namespace AngularPocWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();
            var connectionString = new ConnectionString(Configuration.GetConnectionString(AngularPocConnection));
            services.AddSingleton(connectionString);
            services.AddHttpClient<JwtTokenServiceClient>();
            services.AddControllers();
            //    .AddJsonOptions(opts =>
            //{
            //    opts.JsonSerializerOptions.Converters.Add(new DictionaryTKeyEnumTValueConverter());
            //});// Dictionary serilization bug in asp.net core so fixed it 
            var httpClientSettings = Configuration.GetSection(nameof(HttpClientSettings));
            services.Configure<HttpClientSettings>(httpClientSettings);

            services.AddScoped<IUserRepository>( u=> new UserRepository(connectionString));
            services.AddScoped<IRolesRespository>(r=> new RolesRepository(connectionString));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors(
                 options => options.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader()
                );
            app.UseMiddleware<AuthenticationJwt>();
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
