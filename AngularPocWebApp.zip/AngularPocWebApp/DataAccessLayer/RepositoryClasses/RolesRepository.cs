﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DataModels.Classes;
using DataModels.Interfaces;

namespace DataAccessLayer.RepositoryClasses
{
    public class RolesRepository : IRolesRespository
    {
        private const string SpGetRoles = "SP_GetRoles";
        private readonly ConnectionString _connectionString;
        public RolesRepository(ConnectionString connectionString)
        {
            _connectionString = connectionString;
        }
        public async Task<IEnumerable<Roles>> GetRoles()
        {
            IEnumerable<Roles> roles;
            using (var connection = new SqlConnection(_connectionString.Value))
            {
                await connection.OpenAsync();
                roles = await connection.QueryAsync<Roles>(SpGetRoles,
                        commandType: CommandType.StoredProcedure);
            }
            return roles;
        }

        
    }
}
