﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DataModels.Classes;
using DataModels.Interfaces;

namespace DataAccessLayer.RepositoryClasses
{
    public class UserRepository : IUserRepository
    {
        private const string SpGetUserDetails = "SP_GetUserDetails";
        private const string PUserName = "@UserName";
        private const string UserSplitOn = "UserID,RoleID";
        private readonly ConnectionString _connectionString;
        public UserRepository(ConnectionString connectionString)
        {
            _connectionString = connectionString;
        }
        //public async Task<IEnumerable<UserDetails>> GetUserDetails(string userName)
        //{
        //    IEnumerable<UserDetails> userDetails;

        //    using (var connection = new SqlConnection(_connectionString.Value))
        //    {
        //        await connection.OpenAsync();
        //        var dynamicParams = new DynamicParameters();
        //        dynamicParams.Add(PUserName, userName);
        //        userDetails = await connection.QueryAsync<UserDetails, Roles, UserDetails>(SpGetUserDetails,
        //            (UserDetails, Roles) =>
        //            { UserDetails.Roles = new List<Roles>(); UserDetails.Roles.Add( Roles) ;return UserDetails;  }, dynamicParams,splitOn: UserSplitOn,
        //                commandType: CommandType.StoredProcedure);

        //    }
        //    return userDetails;
        //}

        public async Task<IEnumerable<UserDetails>> GetUserDetails(string userName)
        {
            IEnumerable<UserDetails> userDetails;
            IEnumerable<Roles> roles;

            using (var connection = new SqlConnection(_connectionString.Value))
            {
                await connection.OpenAsync();
                var dynamicParams = new DynamicParameters();
                dynamicParams.Add(PUserName, userName);
              var   result = await connection.QueryMultipleAsync(SpGetUserDetails,
                     dynamicParams, 
                        commandType: CommandType.StoredProcedure);
                roles = await result.ReadAsync<Roles>();
                userDetails =await  result.ReadAsync<UserDetails>();              
                
                userDetails.ElementAtOrDefault(0).Roles = new List<Roles>();
                userDetails.ElementAtOrDefault(0).Roles.AddRange(roles);
            }
            return userDetails;
        }

    }
}
